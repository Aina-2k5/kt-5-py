from fastapi import APIRouter, Request, Form, Depends, HTTPException
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from .. import models, database, auth

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()

def check_owner(post, user):
    if not post or post.author_id != user.id:
        raise HTTPException(status_code=403)

@router.get("/")
def index(request: Request, db: Session = Depends(get_db)):
    posts = db.query(models.Post).order_by(models.Post.created_at.desc()).all()
    return templates.TemplateResponse("index.html", {
        "request": request, "posts": posts, 
        "current_user": auth.get_current_user(request, db) if request.session.get("user_id") else None
    })

@router.get("/posts/{post_id}")
def post_detail(request: Request, post_id: int, db: Session = Depends(get_db)):
    post = db.query(models.Post).filter(models.Post.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404)
    return templates.TemplateResponse("post.html", {
        "request": request, "post": post,
        "current_user": db.query(models.User).filter(models.User.id == request.session.get("user_id")).first() if request.session.get("user_id") else None
    })

@router.get("/create")
def create(request: Request):
    if not request.session.get("user_id"):
        return RedirectResponse(url="/login")
    return templates.TemplateResponse("create.html", {"request": request})

@router.post("/create")
def create_post(request: Request, title: str = Form(...), body: str = Form(...), db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == request.session.get("user_id")).first()
    if user:
        db.add(models.Post(title=title, body=body, author_id=user.id))
        db.commit()
    return RedirectResponse(url="/", status_code=303)

@router.get("/edit/{post_id}")
def edit(request: Request, post_id: int, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == request.session.get("user_id")).first()
    if not user:
        return RedirectResponse(url="/login")
    post = db.query(models.Post).filter(models.Post.id == post_id).first()
    check_owner(post, user)
    return templates.TemplateResponse("edit.html", {"request": request, "post": post})

@router.post("/edit/{post_id}")
def update(request: Request, post_id: int, title: str = Form(...), body: str = Form(...), db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == request.session.get("user_id")).first()
    if user:
        post = db.query(models.Post).filter(models.Post.id == post_id).first()
        check_owner(post, user)
        post.title = title
        post.body = body
        db.commit()
    return RedirectResponse(url="/", status_code=303)

@router.post("/delete/{post_id}")
def delete(request: Request, post_id: int, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == request.session.get("user_id")).first()
    if user:
        post = db.query(models.Post).filter(models.Post.id == post_id).first()
        check_owner(post, user)
        db.delete(post)
        db.commit()
    return RedirectResponse(url="/", status_code=303)